# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['scbs']

package_data = \
{'': ['*']}

install_requires = \
['click-help-colors>=0.9,<0.10',
 'click>=7.1.2,<8.0.0',
 'colorama>=0.3.9,<0.4.0',
 'numba>=0.53.0,<0.54.0',
 'numpy>=1.20.1,<2.0.0',
 'pandas>=1.2.3,<2.0.0',
 'scipy>=1.6.1,<2.0.0',
 'sklearn>=0.0,<0.1',
 'statsmodels>=0.12.2,<0.13.0',
 'umap-learn @ git+https://github.com/lmcinnes/umap.git@0.5.1']

entry_points = \
{'console_scripts': ['scbs = scbs.cli:cli']}

setup_kwargs = {
    'name': 'scbs',
    'version': '0.2.4',
    'description': 'command line utility to work with single cell methylation data',
    'long_description': None,
    'author': 'Lukas PM Kremer',
    'author_email': 'L-Kremer@web.de',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<3.10',
}


setup(**setup_kwargs)
